insert into reserva values(1234567890, 12345678901, TO_DATE('01/01/2011', 'dd/mm/yyyy'), '07:00', '15:00');
insert into reserva values(2345678901, 12345678902, TO_DATE('02/02/2012', 'dd/mm/yyyy'), '08:00', '18:00');
insert into reserva values(3456789012, 12345678903, TO_DATE('03/03/2013', 'dd/mm/yyyy'), '09:00', '19:00');
insert into reserva values(4567890123, 12345678904, TO_DATE('04/04/2014', 'dd/mm/yyyy'), '10:00', '20:00');
insert into reserva values(5678901234, 12345678905, TO_DATE('05/05/2015', 'dd/mm/yyyy'), '11:00', '17:00');
insert into reserva values(6789012345, 12345678906, TO_DATE('06/06/2016', 'dd/mm/yyyy'), '12:00', '22:00');
insert into reserva values(7890123456, 12345678907, TO_DATE('07/07/2017', 'dd/mm/yyyy'), '13:00', '26:00');
insert into reserva values(8901234567, 12345678908, TO_DATE('08/08/2018', 'dd/mm/yyyy'), '14:00', '23:00');

insert into guarda values(1234567890, 101);
insert into guarda values(2345678901, 102);
insert into guarda values(3456789012, 103);
insert into guarda values(4567890123, 104);
insert into guarda values(5678901234, 201);
insert into guarda values(6789012345, 201);
insert into guarda values(7890123456, 301);
insert into guarda values(8901234567, 401);