insert into bates values (12345678901, '08:00:10', '17:00:00', 'Grove Street, 100');

insert into slt_sala_de_trabalho values( 12345678901, 001, 001, 'escritorio');
insert into slt_sala_de_trabalho values( 12345678901, 002, 002, 'escritorio');
insert into slt_sala_de_trabalho values( 12345678901, 003, 003, 'banheiro');
insert into slt_sala_de_trabalho values( 12345678901, 004, 004, 'recepcao');
insert into slt_sala_de_trabalho values( 12345678901, 005, 005, 'cozinha');

insert into and_andar values(001, 12345678901);
insert into and_andar values(002, 12345678901);
insert into and_andar values(003, 12345678901);
insert into and_andar values(004, 12345678901);

insert into quarto values(101, 100.00, 'Regular', 001);
insert into quarto values(102, 100.00, 'Regular', 001);
insert into quarto values(103, 150.00, 'Premium', 001);
insert into quarto values(104, 200.00, 'Gold', 001);
insert into quarto values(201, 100.00, 'Regular', 002);
insert into quarto values(202, 100.00, 'Regular', 002);
insert into quarto values(203, 150.00, 'Premium', 002);
insert into quarto values(204, 200.00, 'Gold', 002);
insert into quarto values(301, 100.00, 'Regular', 003);
insert into quarto values(302, 100.00, 'Regular', 003);
insert into quarto values(303, 150.00, 'Premium', 003);
insert into quarto values(304, 200.00, 'Gold', 003);
insert into quarto values(401, 100.00, 'Regular', 004);
insert into quarto values(402, 100.00, 'Regular', 004);
insert into quarto values(403, 150.00, 'Premium', 004);
insert into quarto values(404, 200.00, 'Gold', 004);